﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace beethoven3
//{
//    class RightNoteInfo
//    {  
//        #region declarations
//        private Sprite sprite;
//        private int index;


//        #endregion

//        #region constructor
//        public RightNoteInfo(Sprite sprite,int index)
//        {
//            this.sprite = sprite;
//            this.index = index;
//        }
//        #endregion

//        #region method

//        public Sprite Sprite
//        {
//            get { return sprite; }
//            set { sprite = value; }

//        }

//        public int Index
//        {
//            get { return index; }
//            set { index = value; }

//        }

    
//        #endregion

//    }
//}
