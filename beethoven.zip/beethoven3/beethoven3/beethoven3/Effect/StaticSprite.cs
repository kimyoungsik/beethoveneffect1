﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.Graphics;

//namespace beethoven3
//{
//    class StaticSprite : Sprite
//    {

//        public StaticSprite(
//            Vector2 location,
//            Texture2D texture,
//            Rectangle initialFrame,
//            Vector2 velocity,
            
//            float scale)
//            : base(location, texture, initialFrame, velocity,scale)
//        {
          
          
//        }


//        public override void Update(GameTime gameTime)
//        {
           
              
            
//        }

//        public override void Draw(SpriteBatch spriteBatch)
//        {
          
//                base.Draw(spriteBatch);

            
//        }
//    }
//}
