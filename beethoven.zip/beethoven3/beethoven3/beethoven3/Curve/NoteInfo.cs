﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
namespace beethoven3
{
    /// <summary>
    /// 오른손노트의 골드라인  
    /// </summary>
    class NoteInfo
    {

        #region declarations
        private bool isRight;
        private double startTime;
        private int markLocation;
        private String type;
        private double lastTime;
        private Vector2 startPoint;
        private Vector2 firstOperatorPoint;
        private Vector2 secondOperatorPoint;
        private Vector2 endPoint;


        #endregion

        #region constructor
        public NoteInfo(bool isRight, double startTime, int markLocation, String type, double lastTime,Vector2 startPoint, Vector2 firstOperatorPoint, Vector2 secondOperatorPoint, Vector2 endPoint)
        {
            this.isRight = isRight;
            this.startTime = startTime;
            this.markLocation = markLocation;
            this.type = type;
            this.lastTime = lastTime;
            this.startPoint = startPoint;
            this.firstOperatorPoint = firstOperatorPoint;
            this.secondOperatorPoint = secondOperatorPoint;
            this.endPoint = endPoint;
        }
        #endregion

        #region method

        public Vector2 StartPoint
        {
            get { return startPoint; }
            set { startPoint = value; }

        }

        public Vector2 FirstOperatorPoint
        {
            get { return firstOperatorPoint; }
            set { firstOperatorPoint = value; }

        }

        public Vector2 SecondOperatorPoint
        {
            get { return secondOperatorPoint; }
            set { secondOperatorPoint = value; }

        }

        public Vector2 EndPoint
        {
            get { return endPoint; }
            set { endPoint = value; }

        }
        public double LastTime
        {
            get { return lastTime; }
            set { lastTime = value; }

        }
        public String Type
        {
            get { return type; }
            set { type = value; }

        }
        public bool IsRight
        {
            get { return isRight; }
            set { isRight = value; }
        }

        public double StartTime
        {
            get { return startTime; }
            set { startTime = value; }
        }

        public int MarkLocation
        {
            get { return markLocation; }
            set { markLocation = value; }
        }
        #endregion

    }
}
